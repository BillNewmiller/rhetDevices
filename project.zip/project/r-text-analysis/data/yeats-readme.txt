"Yeats usually composed very slowly and with painful effort. 
He tells us in his autobiography that 'five or six lines in 
two or three laborious hours were a day's work, and I longed 
for somebody to interrupt me.' His manuscripts show that slow 
evolution of his best poems, which sometimes began with a prose 
sketch, were then versified, and underwent numerous revisions. 
In many instances, even after the poems had been published, 
Yeats continued to revise them, sometimes drastically, in later 
printings."
[from the Norton Anthology of English Literature, 8th Ed. Vol. 2 (2006), A19.]

For this exercise, use Diffchecker at https://www.diffchecker.com/diff 
to compare the 1891 manuscript version of Yeats's "The Sorrow of Love" 
with its 1892 first printed version, and compare the 1892 version with 
the final printed version of 1925. What are the significant differences 
among these different stages of transmission, and what do they reveal 
about Yeats's evolving thematic intentions for the poem?