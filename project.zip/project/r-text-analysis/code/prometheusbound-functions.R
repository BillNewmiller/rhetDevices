#set working directory under Session menu item to folder containing prometheusbound-plain-text.txt
options(max.print=.Machine$integer.max)
#Create character vector using the scan function
text.v <- scan("prometheusbound-plain-text.txt", what="character", sep = "\n")
#Display results in Consule
text.v
#Remove line breaks
words.v<-paste(text.v,collapse=" ")
words.v
#Convert all text to lower case
words.lower.v<-tolower(words.v)
words.lower.v
#Tokenize to isolate the words, observing all alpha-characters (a-z), apostrophes ('), and hyphens (-)
words.l<-strsplit(words.lower.v, "[^a-z'-]")
words.l
#Remove blanks from where punctuation had existed
word.v<-unlist(words.l)
not.blanks.v<-which(word.v!="")
prometheusbound.word.v<-word.v[not.blanks.v]
#Display the vector
prometheusbound.word.v

#With data prep completed, establish frequencies
prometheusbound.freqs.t<-table(prometheusbound.word.v)
prometheusbound.freqs.t
#Arrange frequencies in descending order
sorted.prometheusbound.freqs.t<-sort(prometheusbound.freqs.t,decreasing = TRUE)
#Display the table of frequencies
sorted.prometheusbound.freqs.t
#Output and save the frequency table using the accompanying sink file, sinkFunction.R

#Limit output to hard-hyphen compounds by specifiying instances of alpha-characters containing hyphens ([a-z]*-[a-z]*)
hyphenations.v <- grep("[a-z]*-[a-z]*", word.v)
mypositions.v <- c(hyphenations.v)
hardhyphs.v <- word.v[mypositions.v]
hardhyphs.freqs.t <- table(hardhyphs.v)
sorted.hardhyphs.freqs.t <- sort(hardhyphs.freqs.t, decreasing=T)
sorted.hardhyphs.freqs.t
length(hardhyphs.v)

#Supply character name in regex, and extract substring from match data, creating a list
pro.positions.l<-regmatches(words.v, gregexpr("PROMETHEUS.*?(?=[A-Z]{2,})", perl = TRUE, words.v))
pro.positions.l
#Alter output from list to vector
pro.positions.v<-unlist(pro.positions.l)
#Create a new object based on concatenated results for unified output, separated by line breaks
cat(pro.positions.v, sep = "\n")
#Download using the accompanying sink file, sinkFunction.R

#Determine relative frequency of a given term within the Prometheus text
#Divide the frequencies object by its sum, and multiply (*) by 100
sorted.prometheusbound.rel.freqs.t<-100*(sorted.prometheusbound.freqs.t/sum(sorted.prometheusbound.freqs.t))
#Display the relative frequency for a targeted term
sorted.prometheusbound.rel.freqs.t["mind"]

#Display keywords in context
#Identify positions for the targeted term in the object
positions.v <- which(prometheusbound.word.v[]=="mind")
#Supply quantity of words ("context") to display before and after the target term
context <- 10
#Use a for loop to perform the function on every instance of the target term in the file
for(i in 1:length(positions.v)){
  start <- positions.v[i]-context
  end <- positions.v[i]+context
  before <- prometheusbound.word.v[start:(start+context-1)]
  after <- prometheusbound.word.v[(start+context+1):end]
  keyword <- prometheusbound.word.v[start+context]
  cat("--------------", i, "--------------", "\n")
  cat(before,"[",keyword, "]", after, "\n")
}

