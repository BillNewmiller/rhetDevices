#set working directory under Session menu item to folder containing frankenstein1818-plain-text.txt
options(max.print=.Machine$integer.max)
#Create character vector using the scan function
text.v <- scan("frankenstein1818.txt", what="character", sep = "\n")
#Display results in Consule
text.v
#Remove line breaks
words.v<-paste(text.v,collapse=" ")
words.v
#Convert all text to lower case
words.lower.v<-tolower(words.v)
words.lower.v
#Tokenize to isolate the words, observing all alpha-characters (a-z), apostrophes ('), and hyphens (-)
words.l<-strsplit(words.lower.v, "[^a-z'-]")
words.l
#Remove blanks from where punctuation had existed
word.v<-unlist(words.l)
not.blanks.v<-which(word.v!="")
frankenstein1818.word.v<-word.v[not.blanks.v]
#Display the vector
frankenstein1818.word.v

#With data prep completed, establish frequencies
frankenstein1818.freqs.t<-table(frankenstein1818.word.v)
frankenstein1818.freqs.t
#Arrange frequencies in descending order
sorted.frankenstein1818.freqs.t<-sort(frankenstein1818.freqs.t,decreasing = TRUE)
#Display the table of frequencies
length(sorted.frankenstein1818.freqs.t)
#Output and save the frequency table using the accompanying sink file, sinkFunction.R

#Limit output to hard-hyphen compounds by specifiying instances of alpha-characters containing hyphens ([a-z]*-[a-z]*)
hyphenations.v <- grep("[a-z]*-[a-z]*", word.v)
mypositions.v <- c(hyphenations.v)
hardhyphs.v <- word.v[mypositions.v]
hardhyphs.freqs.t <- table(hardhyphs.v)
sorted.hardhyphs.freqs.t <- sort(hardhyphs.freqs.t, decreasing=T)
sorted.hardhyphs.freqs.t
length(hardhyphs.v)

#Supply character name in regex, and extract substring from match data, creating a list
frankenstein1818.positions.l<-regmatches(words.v, gregexpr("LETTER.*?(?=[A-Z]{2,})", perl = TRUE, words.v))
frankenstein1818.positions.l
#Alter output from list to vector
frankenstein1818.positions.v<-unlist(frankenstein1818.positions.l)
#Create a new object based on concatenated results for unified output, separated by line breaks
cat(frankenstein1818.positions.v, sep = "\n")
#Download using the accompanying sink file, sinkFunction.R

#Determine relative frequency of a given term within the frankenstein1818metheus text
#Divide the frequencies object by its sum, and multiply (*) by 100
sorted.frankenstein1818.rel.freqs.t<-100*(sorted.frankenstein1818.freqs.t/sum(sorted.frankenstein1818.freqs.t))
#Display the relative frequency for a targeted term
sorted.frankenstein1818.rel.freqs.t["fate"]

#Display keywords in context
#Identify positions for the targeted term in the object
positions.v <- which(frankenstein1818.word.v[]=="victor")
#Supply quantity of words ("context") to display before and after the target term
context <- 5
#Use a for loop to perform the function on every instance of the target term in the file
for(i in 1:length(positions.v)){
  start <- positions.v[i]-context
  end <- positions.v[i]+context
  before <- frankenstein1818.word.v[start:(start+context-1)]
  after <- frankenstein1818.word.v[(start+context+1):end]
  keyword <- frankenstein1818.word.v[start+context]
  cat("--------------", i, "--------------", "\n")
  cat(before,"[",keyword, "]", after, "\n")
}
