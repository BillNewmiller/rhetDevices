#set working directory under Session menu item to folder containing sonnets-plain-text.txt
options(max.print=.Machine$integer.max)
#Create character vector using the scan function
text.v <- scan("sonnets-plain-text.txt", what="character", sep = "\n")
#Display results in consule
text.v
#Remove line breaks
words.v<-paste(text.v,collapse=" ")
words.v
#Convert all text to lower case
words.lower.v<-tolower(words.v)
words.lower.v
#Tokenize to isolate the words, observing all alpha-characters (a-z) and apostrophes (')
words.l<-strsplit(words.lower.v, "[^a-z']")
words.l
#Remove blanks from where punctuation had existed
word.v<-unlist(words.l)
not.blanks.v<-which(word.v!="")
sonnets.word.v<-word.v[not.blanks.v]
#Display the vector
sonnets.word.v

#With data prep completed, establish frequencies
sonnets.freqs.t<-table(sonnets.word.v)
sonnets.freqs.t
#Arrange frequencies in descending order
sorted.sonnets.freqs.t<-sort(sonnets.freqs.t, decreasing = TRUE)
#Display the table of frequencies
sorted.sonnets.freqs.t
#Output and save the frequency table using the accompanying sink file, sinkFunction.R

#Supply roman-numeral sequence in regex, and extract substring from match data, creating a list
sonnets.positions.l<-regmatches(words.v, regexpr("LXXVIII.*?(?=LXXXVII)", perl = TRUE, words.v))
sonnets.positions.l
#Alter output from list to vector
sonnets.positions.v<-unlist(sonnets.positions.l)
#Create a new object based on concatenated results for unified output, separated by line breaks
cat(sonnets.positions.v, sep = "\n")
#Download using the accompanying sink file, sinkFunction.R

#Determine relative frequency of a given term within the Sonnets corpus
#Divide the frequencies object by its sum, and multiply (*) by 100
sorted.sonnets.rel.freqs.t<-100*(sorted.sonnets.freqs.t/sum(sorted.sonnets.freqs.t))
#Display the relative frequency for a targeted term
sorted.sonnets.rel.freqs.t["love"]

#Display keywords in context
#Identify positions for the targeted term in the object
positions.v <- which(sonnets.word.v[]=="love")
#Supply quantity of words ("context") to display before and after the target term
context <- 10
#Use a for loop to perform the function on every instance of the target term in the file
for(i in 1:length(positions.v)){
  start <- positions.v[i]-context
  end <- positions.v[i]+context
  before <- sonnets.word.v[start:(start+context-1)]
  after <- sonnets.word.v[(start+context+1):end]
  keyword <- sonnets.word.v[start+context]
  cat("--------------", i, "--------------", "\n")
  cat(before,"[",keyword, "]", after, "\n")
}


