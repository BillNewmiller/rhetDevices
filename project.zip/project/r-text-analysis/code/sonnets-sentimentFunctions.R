library(tidytext)
library(dplyr)
library(stringr)
library(glue)
library(tidyverse)
library(wordcloud)
library(reshape2)

words <- data_frame(file = paste0(c("sonnets-stringed-plain-text.txt"))) %>%
  mutate(text = map(file, read_lines)) %>%
  unnest() %>%
  group_by(file = str_sub(basename(file), 1, -5)) %>%
  mutate(line_number = row_number()) %>%
  ungroup() %>%
  unnest_tokens(word, text)

words_sentiment <- inner_join(words,
                              get_sentiments("bing")) %>%
  count(file, index = round(line_number/ max(line_number) * 100 / 5) * 5, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(net_sentiment = positive - negative)

words_sentiment <- inner_join(words,
                                get_sentiments("bing")) %>%
  count(file, index = round(line_number/ max(line_number) * 100 / 5) * 5, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(net_sentiment = positive - negative)

bing_word_counts <- words %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  ungroup() 

bing_word_counts %>%
  group_by(sentiment) %>%
  top_n(20) %>%
  ungroup() %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n, fill = sentiment)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~sentiment, scales = "free_y") +
  labs(y = "High Frequency Terms Divided by Sentiment in Shakespeare's Sonnets",
       x = NULL) +
  coord_flip()

# create a sentiment wordcloud 

words %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(max.words = 100, scale = c(.75,1), 
                   random.order = FALSE,
                   colors = c("red", "blue"))

#if you want just to id negative word counts, run this
bing_word_counts <- words %>%
  inner_join(get_sentiments("bing")) %>%
  filter(sentiment == "negative") %>%
  count(word, sentiment, sort = TRUE) %>%
  ungroup() %>% 
  write.csv(., "134-negative-words.csv", row.names=FALSE) #this last bit of code writes the table into a csv file

#for positive words
bing_word_counts <- words %>%
  inner_join(get_sentiments("bing")) %>%
  filter(sentiment == "positive") %>%
  count(word, sentiment, sort = TRUE) %>%
  ungroup() %>%
  write.csv(., "134-positive-words.csv", row.names=FALSE)

