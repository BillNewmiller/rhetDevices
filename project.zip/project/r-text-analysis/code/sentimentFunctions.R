#Install the following packages (a one-time only process) by selecting "Packages" at lower right
#In "Packages" select "Install" and, one at time, enter and install the package titles in parentheses below
library(tidytext)
library(dplyr)
library(stringr)
library(glue)
library(tidyverse)
library(wordcloud)
library(reshape2)

#Once installed, run the above packages as you would a normal line or block of code

#Supply file name within the quotes in line 15 below
#Run the following code from lines 14-38 to prepare data
words <- data_frame(file = paste0(file.choose())) %>%
  mutate(text = map(file, read_lines)) %>%
  unnest() %>%
  group_by(file = str_sub(basename(file), 1, -5)) %>%
  mutate(line_number = row_number()) %>%
  ungroup() %>%
  unnest_tokens(word, text)

words_sentiment <- inner_join(words,
                              get_sentiments("bing")) %>%
  count(file, index = round(line_number/ max(line_number) * 100 / 5) * 5, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(net_sentiment = positive - negative)

words_sentiment <- inner_join(words,
                                get_sentiments("bing")) %>%
  count(file, index = round(line_number/ max(line_number) * 100 / 5) * 5, sentiment) %>%
  spread(sentiment, n, fill = 0) %>%
  mutate(net_sentiment = positive - negative)

bing_word_counts <- words %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  ungroup() 

#Create a sentiment graph to display in the "Plots" tab at lower right
#Revise Y label in line 50 below to correctly identify your target text
bing_word_counts %>%
  group_by(sentiment) %>%
  top_n(20) %>%
  ungroup() %>%
  mutate(word = reorder(word, n)) %>%
  ggplot(aes(word, n, fill = sentiment)) +
  geom_col(show.legend = FALSE) +
  facet_wrap(~sentiment, scales = "free_y") +
  labs(y = "High Frequency Terms Divided by Sentiment in Shakespeare's Sonnets",
       x = NULL) +
  coord_flip()

#Create a sentiment word cluster to display in the "Plots" tab at lower right 
words %>%
  inner_join(get_sentiments("bing")) %>%
  count(word, sentiment, sort = TRUE) %>%
  acast(word ~ sentiment, value.var = "n", fill = 0) %>%
  comparison.cloud(max.words = 100, scale = c(.75,1), 
                   random.order = FALSE,
                   colors = c("red", "blue"))



