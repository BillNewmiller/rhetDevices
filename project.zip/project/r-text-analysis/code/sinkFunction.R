#Creates and names a file in the working directory
sink("personification.doc")
#sink function exports specified object to the newly created file
print(output.l)
#concludes the sink function
sink()
