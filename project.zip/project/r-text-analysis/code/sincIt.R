sincit <- function(fileName, dataVar){
  #Creates and names a file in the working directory
  sink(fileName)
  #sink function exports specified object to the newly created file
  print(cat(dataVar, sep = "\n"))
  #concludes the sink function
  sink()
} 