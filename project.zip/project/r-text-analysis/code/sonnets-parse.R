#code lines 6-13 will produce clean output for words and phrases tagged
#with the specified device value
#lines 15-20 will produce tagged content within their clausal parent elements
library(XML)
options(max.print = .Machine$integer.max)
doc <- xmlTreeParse("sonnets_combined.xml", useInternalNodes=TRUE)

#outputs device-level values
fairyouth.divs.ns.l <- getNodeSet(doc, "/body/*[@ana='#theme-fairyouth' or @ana='#theme-rivalpoet' or @ana='#theme-darklady' or @ana='#theme-other']//simile")
fairyouth.divs.ns.l
objects.v <- sapply(fairyouth.divs.ns.l, xmlValue)
device.v <- gsub("  ", "", objects.v)
device.v <- gsub("[\r\n]", " ", device.v)
device.v

#outputs clauses with relevant device-level values
fairyouth.divs.ns.l <- getNodeSet(doc, "/body/*[@ana='#theme-fairyouth' or @ana='#theme-rivalpoet' or @ana='#theme-darklady' or @ana='#theme-other']//simile/ancestor-or-self::node()[position()=2]")
objects.v <- sapply(fairyouth.divs.ns.l, xmlValue)
device.v <- gsub("  ", "", objects.v)
device.v <- gsub("[\r\n]", " ", device.v)
device.v

