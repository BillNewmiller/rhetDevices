library(XML)
doc <- xmlTreeParse("sonnets_combined.xml", useInternalNodes=TRUE)
sonnets.ns.l <- getNodeSet(doc, "/body//*[@ana='#theme-fairyouth' or @ana='#theme-rivalpoet' or @ana='#theme-darklady' or @ana='#theme-other']")
sonnet.title <- xmlElementsByTagName(sonnets.ns.l[[1]], "head")

#display any individual sonnet or range of sonnets (using all four thematic sequences)
sonnets.ns.l[10]
sonnets.ns.l[106:107]

#Run a for loop to ouput rhetorical content by sonnet roman numeral
#Create list item to hold the content
output.l <- list()
#Begin for loop
for(i in  1:length(sonnets.ns.l)){
  #extract the sonnet title from the head element
  sonnet.title <- xmlValue(xmlElementsByTagName(sonnets.ns.l[[i]], "head")[[1]])
  #specify contents by tag attribute
  words.ns <- xmlElementsByTagName(sonnets.ns.l[[i]], "personification", recursive = TRUE)
  #combine all the words from the specified content
    sonnet.words.v <- paste(sapply(words.ns, xmlValue))
  #convert to lowercase
  words.lower.v <- tolower(sonnet.words.v)
  #list output by sonnet title
  output.l[[sonnet.title]] <- words.lower.v
}
#display output
output.l


